package si.sunesis.interoperability.lpc.transformations.enums;

public enum Endianness {
    LITTLE_ENDIAN,
    BIG_ENDIAN,
    LITTLE_ENDIAN_SWAP,
    BIG_ENDIAN_SWAP
}
