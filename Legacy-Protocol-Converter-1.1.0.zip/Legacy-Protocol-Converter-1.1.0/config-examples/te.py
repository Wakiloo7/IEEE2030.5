"""Reading from FINDER 6M.TA

In "Modbus communication protocol" manual, the registers are indicated in the 4xxxx locations
However, 0xxxx-1 should be considered instead

relevant/example values:
- Machine ID: register 0 (1 register, unsigned short), value=7 for 6M.TA
- Modbus Address: register 2 (1 register, unsigned short)
- Baudrate: register 4 (1 register, unsigned short), value=3 for baudrate of 9600
- Parity: register 5 (1 register, unsigned short), value=0 for "No Parity"

- Voltage in A/100: register 192 (2 registers, LSW first, signed long)
- Current in A/100: register 194 (2 registers, LSW first, signed long)
- Power in W/100: register 196 (2 registers, LSW first, signed long)
- Energy Total in kWh/100: register 208 (2 registers, LSW first, signed long)
- Energy positive in kWh/100: register 210 (2 registers, LSW first, signed long)
- Energy negative in kWh/100: register 212 (2 registers, LSW first, signed long)

Available devices

ID = 1 -> String 1, Grupo B
ID = 2 -> String 2, Grupo B
ID = 3 -> String 3, Grupo B
ID = 4 -> String 1, Grupo A
ID = 5 -> String 2, Grupo A
ID = 6 -> String 3, Grupo A

"""
import time
import struct
import modbus_tk
import modbus_tk.defines as cst
from modbus_tk import modbus_tcp

IP = '192.168.212.52'
port = 502
# the lists below refer to the registers of the following quantities (in the presented order)
# Voltage, Current, Power, Energy (last minute), Energy_returned (last minute), Energy (total), Energy_returned (total)
regl = [192, 194, 196, 208]
#regl = [6]
LengthRegl = [2, 2, 2, 2]
#LengthRegl = [2]
scaleL = [0.01, 0.00001, 0.01, 0.01]
#scaleL = [1]
string_list = ['Voltage (DC):', 'Current (DC):', 'Power:', 'Energy Total']

def read_values(ID, IP, port, regl, LengthRegl, scaleL, string_list):

    client = modbus_tcp.TcpMaster(IP, port)
    for r in range(len(regl)):
        values = client.execute(ID, cst.READ_HOLDING_REGISTERS, regl[r], LengthRegl[r])
        # values = write_unsigned_short_to_modbus(client, ID, regl[r], 5) # write unsigned short
        # values = write_float_to_modbus(client, ID, regl[r], 1.0, byte_order='big')
        # convert to binary, noting that the less significant bit is the first, reason why order is changed
        combined_bytes = struct.pack('>H', values[1]) + struct.pack('>H', values[0])

        result = (int.from_bytes(byteorder='big', bytes=combined_bytes))
        # check if the most significant bit is 1
        if (result & (1 << 31)) != 0:
            # print('Negative value')
            result = (result - (1 << 32)) * scaleL[r]
        else:
            result = result * scaleL[r]
        print('Device: ', ID, '-', string_list[r], result) #long
        # print('Device: ', ID, '-', string_list[r], values[0])  # short
        # print('Device: ', ID, '-', modbus_to_float(values)) # float
    client.close()


def modbus_to_float(registers, byte_order='big'):
    if byte_order == 'big':
        # Combine the registers in big-endian order
        combined = (registers[0] << 16) | registers[1]
    else:
        # Combine the registers in little-endian order
        combined = (registers[1] << 16) | registers[0]

    # Pack the combined integer into a binary string, then unpack as a float
    float_value = struct.unpack('!f', struct.pack('!I', combined))[0]
    return float_value


def float_to_modbus(value, byte_order='big'):
    # Pack the float into a binary string
    packed_value = struct.pack('!f', value)
    # Unpack the binary string into an integer
    int_value = struct.unpack('!I', packed_value)[0]

    if byte_order == 'big':
        # Split the integer into two 16-bit registers (big-endian)
        register1 = (int_value >> 16) & 0xFFFF
        register2 = int_value & 0xFFFF
    else:
        # Split the integer into two 16-bit registers (little-endian)
        register1 = int_value & 0xFFFF
        register2 = (int_value >> 16) & 0xFFFF

    return register1, register2


def float_to_modbus_32bit(value, byte_order='big'):
    # Pack the float into a binary string
    packed_value = struct.pack('!f', value)
    # Unpack the binary string into an integer
    int_value = struct.unpack('!I', packed_value)[0]

    if byte_order == 'big':
        # For big-endian, the integer remains as is
        return int_value
    else:
        # For little-endian, swap the byte order
        swapped_value = struct.unpack('<I', struct.pack('>I', int_value))[0]
        return swapped_value


def write_float_to_modbus(client, ID, address, value, byte_order='big'):
    modbus_32bit_value = float_to_modbus_32bit(value, byte_order)
    registers = [modbus_32bit_value >> 16, modbus_32bit_value & 0xFFFF]

    # Write the registers to the specified address and capture the response
    response = client.execute(ID, cst.WRITE_MULTIPLE_REGISTERS, address, output_value=registers)
    return response


def write_unsigned_short_to_modbus(client, ID, address, value):
    # Ensure the value is within the range of an unsigned short (0 to 65535)
    if not (0 <= value <= 0xFFFF):
        raise ValueError("Value out of range for an unsigned short: 0 to 65535")

    # Write the unsigned short value to the specified address
    response = client.execute(ID, cst.WRITE_SINGLE_REGISTER, address, output_value=value)
    return response


while True:
    try:
        for ID in range(1, 7):
            read_values(ID, IP, port, regl, LengthRegl, scaleL, string_list)
            time.sleep(0.5)
        time.sleep(5)
    except Exception as e:
        print(e)
        break



